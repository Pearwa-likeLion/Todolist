from django import http
from django.shortcuts import render
from django.http import JsonResponse

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .serializers import TodolistSerializer
from .models import Todolist

#GET DAta
@api_view(['GET'])
def all_todolist(request):
    alltodolist = Todolist.objects.all()
    serializer = TodolistSerializer(alltodolist,many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['POST'])
def post_todolist(request):
    if request.method == 'POST':
        serializer = TodolistSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)

@api_view(['PUT'])
def update_todolist(request,TID):
    # localhost:8000/api/update-todolist/13
    todo = Todolist.objects.get(id=TID)

    if request.method == 'PUT':
        data = {}
        serializer = TodolistSerializer(todo,data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['status'] = 'updated'
            return Response(data=data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)

@api_view(['DELETE'])
def delete_todolist(request,TID):
    todo = Todolist.objects.get(id=TID)

    if request.method == 'DELETE':
        delete = todo.delete()
        data = {}
        if delete:
            data['status'] = 'deleted'
            statuscode = status.HTTP_200_OK
        else:
            data['status'] = 'failed'
            statuscode = status.HTTP_400_BAD_REQUEST

        return Response(data=data,status=statuscode)




data = [
    {
        "title" : "Pat1 58-63",
        "subtitle" : "ความถนัดทางคณิตศาสตร์ตั้งแต่ปี พ.ศ. 2558- 2563",
        "image_url" : "https://raw.githubusercontent.com/Pearwa-likeLion/BasicAPI/main/bookshelf.jpg",
        "detail": "0 ข้อสอบ PAT 1 - กุมภาพันธ์ 2563 \n\n    ข้อสอบ PAT 1 - กุมภาพันธ์ 2562 \n\n2    ข้อสอบ PAT 1 - กุมภาพันธ์ 2561  \n\n3   ข้อสอบ PAT 1 - มีนาคม 2560  \n\n4   ข้อสอบ PAT 1 - ตุลาคม 2559 \n\n 5   ข้อสอบ PAT 1 - มีนาคม 2559  \n\n6   ข้อสอบ PAT 1 - ตุลาคม 2558  \n\n7   ข้อสอบ PAT 1 - มีนาคม 2558  \n\n8   ข้อสอบ PAT 1 - พฤศจิกายน 2557 ข้อสอบ \n\n 9 ข้อสอบ PAT 1 - เมษายน 2557  \n\n10  ข้อสอบ PAT 1 - มีนาคม 2557    \n\n11  ข้อสอบ PAT 1 - มีนาคม 2556  \n\n12  ข้อสอบ PAT 1 - ตุลาคม 2555  \n\n13  ข้อสอบ PAT 1 - มีนาคม 2555 \n\n14   ข้อสอบคณิต 9 สามัญ - ปี 2563    \n\n15  ข้อสอบคณิต 9 สามัญ - ปี 2562    \n\n16 ข้อสอบคณิต 9 สามัญ - ปี 2561 \n\n17 ข้อสอบคณิต 9 สามัญ - ปี  2560\n\n18 ข้อสอบคณิต 9 สามัญ - ปี 2559 \n\n19 ข้อสอบคณิต 9 สามัญ - ปี 2559"
    },
    {
        "title" : "About",
        "subtitle" : "About me เกี่ยวกับการเล่าแรงบันดานใจ และเรื่องราวการเขียนเว็บไซด์",
        "image_url" : "https://raw.githubusercontent.com/Pearwa-likeLion/BasicAPI/main/sand.jpg",
        "detail": "This is Me: นางสาวแพรวา ทัศนภูมิ หรือแพรวา นักเรียนชั้นมัธยมศึกษาปีที่ 6 สายการเรียน SMTE ที่กำลังจะศึกษาต่อมหาวิทยาลัย สนใจในด้านคอมพิวเตอร์การเขียนโปรแกรมเป็นอย่างมาก ได้รับแรงบันดานใจมาจาก Steve Job ซึ่งเป็นไอดอลที่ชื่นชอบในวัยเด็กและเมื่อโตขึ้นก็ยังมีพี่สาวทั้งสองที่จบวิศวกรรมคอมพิวเตอร์ซึ่งตอนนี้เป็นโปรแกรมเมอร์อยู่ในบริษัทในกรุงเทพเป็น ไอดอลมาจนถึงทุกวันนี้ ชอบงานที่พี่เขาทำและรู้สึกว่าสุดยอดมากๆ เกิดความสนใจจึงศึกษาด้านนี้ตลอดมา ได้เรียนรู้เกี่ยวกับpython และนำความรู้มาสร้าง 'Website' และ ทำการศึกษาเพิ่มเติมเกี่ยวกับ html พัฒนาความรู้และพบเจออุปสรรคหรือปัญหาต่างๆในการทำงานจริงมากมาย แต่สุดท้ายก็พยายามจนสามารถทำให้สำเร็จได้\n\nอย่าคิดว่าปัญหาคือสิ่งที่แก้ไม่ได้ ทุกปัญหามีทางแก้และจงพยายยามเพื่อที่จะไปยัง 'Goal' ที่คุณตั้งไว้"
    },
    {
        "title" : "Contact",
        "subtitle" : "ช่องทางการติดต่อ อีเมล หรือการแสดงความคิดเห็นเกี่ยวกับเว็บไซด์นี้",
        "image_url" : "https://raw.githubusercontent.com/Pearwa-likeLion/BasicAPI/main/contactus.jpg",
        "detail": "E-mail: FITTOKUNG@GMAIL \n\n Facebook : Pearwa Tuss \n\n Phone : 095 416 0491 "
    }


]

def Home(request):
     return JsonResponse(data=data , safe=False,json_dumps_params={'ensure_ascii': False})